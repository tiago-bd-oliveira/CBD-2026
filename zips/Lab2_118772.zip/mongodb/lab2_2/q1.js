
db.restaurants.find()

